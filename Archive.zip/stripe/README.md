# Accept a Payment with Stripe Checkout

Stripe Checkout is the fastest way to get started with payments. Included are some basic build and run scripts you can use to start up the application.

## Running the sample

1. Build the server

~~~
composer install
~~~

2. Run the server

~~~
php -S 127.0.0.1:4242 --docroot=public
~~~

3. Go to [http://localhost:4242/checkout.html](http://localhost:4242/checkout.html)# strip-payment-sample


4.  /*

Test Card Details
To test the payment process, you need test card details. Use any of the following test card numbers, a valid future expiration date, and any random CVC number, to test Stripe payment gateway integration in PHP.

4242 4242 4242 4242 – Visa
4000 0566 5566 5556 – Visa (debit)
5555 5555 5555 4444 – Mastercard
5200 8282 8282 8210 – Mastercard (debit)
3782 822463 10005 – American Express
6011 1111 1111 1117 – Discover
3566 0020 2036 0505 – JCB
6200 0000 0000 0005 – UnionPay
3D Secure Authentication
The 3D Secure feature requires additional authentication for credit card transactions. Use the following test cards to simulate the payment process that involves 3D Secure authentication.

4000 0027 6000 3184
4000 0000 0000 3063



*/