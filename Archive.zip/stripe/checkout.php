<?php

error_reporting(E_ALL & ~E_NOTICE & ~E_STRICT & ~E_DEPRECATED);
ini_set('display_errors', 0);
ob_start();
require 'vendor/autoload.php';

$stripe = new \Stripe\StripeClient('sk_test_51P92yrKWEFucjjkjXhvnS63gCxnPrbbXYyWzarPLClejFC3gsk3coJlqMOa4AgATfz2ifMQj2v1L6OEbqXbjrqHm00ASVrwW1p');

// Decode and sanitize input
$decodedAmount = base64_decode($_GET['am']);
$fullname = base64_decode($_GET['nm']);
$email = base64_decode($_GET['em']);
$program = base64_decode($_GET['program']);

// Convert to cents (Stripe expects integer in cents)
$amount = (int)($decodedAmount * 100); // e.g. 100 * 100 = 10000


$encodedAmount = urlencode($amount);
$encodedProgram = urlencode($program);

$success_url = 'http://localhost/ProjectHQ/successful.php?am=' . $encodedAmount . '&program=' . $program;

// Create Stripe checkout session
$checkout_session = $stripe->checkout->sessions->create([
  'line_items' => [[
    'price_data' => [
      'currency' => 'usd',
      'product_data' => [
        'name' => $fullname . ' - ' . $program, 
      ],
      'unit_amount' => $amount, 
    ],
    'quantity' => 1,
  ]],
  'mode' => 'payment',
  'success_url' => $success_url,
  'cancel_url' => 'http://localhost/ProjectHQ/thankyou.php',
]);

// Redirect to Stripe Checkout
header("HTTP/1.1 303 See Other");
header("Location: " . $checkout_session->url);
exit;
?>
